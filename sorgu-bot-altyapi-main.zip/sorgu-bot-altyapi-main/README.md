kendi yazdığım bot draco tarafından çalınınca botu public etme kararı aldım alın yayın kime atıyosanız atın adamdan almayın herhangi bir soru için DC: Retnox#2728 Daha gelişmiş slash ve üyelik tanımlı sistemli olanı da satıyorum yazabilirsiniz dc ime ayarlar.json a botun tokenini ve idsini koyup ardından start.bat ı çalıştırdığınızda bot çalışmaya başlar. isteğinize göre özelleştirebilirsiniz. module not found hatası alırsanız npm i modülismi yazarak modülleri indirebilirsiniz botun intentlerini açmayı unutmayın çok kolay aslında herkes yapabilir boşuna bazı kişilere prim vermeyelim bu bota yakın bot yazan herkes panelciyim uhu diye geziyor bu işin allahı retnoxdur iyi eğlenceler.

101M DATA ISIM SOYISIM
http://www.mediafire.com/file/v0rdjl466n732sg/101m.7z
116M GSM TELEFON
https://bayfiles.com/n4x2afPfyd#!/VxlfcwdKPrTnaERn



ZİRVEDE BIRAKTIM.
